module.exports = {
  db: {
    mysql: {
      host: 'localhost',
      user: 'root',
      password: '',
      database: 'api_manage'
    }
  }
}
